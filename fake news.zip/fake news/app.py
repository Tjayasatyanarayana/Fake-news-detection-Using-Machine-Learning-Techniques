import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import streamlit as st
import matplotlib.pyplot as plt

# Load the fake news dataset (assuming the dataset has "title" and "label" columns)
data = pd.read_csv("fake_or_real_news.csv")

# Train the model
x = np.array(data["title"])
y = np.array(data["label"])
cv = CountVectorizer()
x = cv.fit_transform(x)
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(xtrain, ytrain)

# Streamlit app
st.title("Fake News Detection System")

def fakenewsdetection():
    # Text area for manual input
    user_text = st.text_area("Enter Any News Headline:")

    # File uploader for document upload
    uploaded_file = st.file_uploader("Upload a file", type=["txt", "pdf", "docx"])

    # Check if a file was uploaded
    if uploaded_file is not None:
        # Read the contents of the file
        text = uploaded_file.read()
        
        # Perform fake news detection on the uploaded content
        data = cv.transform([text]).toarray()
        prediction = model.predict(data)[0]

        # Display the result
        st.write("Prediction (from file upload):", prediction)

    # Check if user entered text
    elif user_text:
        # Perform fake news detection on the entered text
        data = cv.transform([user_text]).toarray()
        prediction = model.predict(data)[0]

        # Display the result
        st.write("Prediction (from text area):", prediction)

        # Display the percentage of fake and real news in a bar chart
        probabilities = model.predict_proba(data)[0]
        labels = ["Fake", "Real"]
        plt.bar(labels, probabilities, color=['red', 'green'])
        plt.title("Fake vs Real News Probability")
        plt.xlabel("News Type")
        plt.ylabel("Probability")
        st.pyplot()

        # Display the coefficients (log-odds) of the features
        feature_names = np.array(cv.get_feature_names())
        coefficients = model.coef_[0]
        top_features_indices = np.argsort(coefficients)[-10:]  # Adjust the number of top features as needed
        top_features = feature_names[top_features_indices]
        log_odds = coefficients[top_features_indices]

        st.write("Top Features Contributing to Prediction:")
        for feature, log_odd in zip(top_features, log_odds):
            st.write(f"{feature}: Log Odds = {log_odd:.4f}")

# Run the fake news detection function
fakenewsdetection()